
int demacro(const char file_name[]);
void phaseOne(int num_label, const char file_name[]);