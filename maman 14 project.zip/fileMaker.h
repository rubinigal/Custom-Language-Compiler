#include "tables.h"

void btou(int num , FILE* file); /* prints the number in a special binaly base */